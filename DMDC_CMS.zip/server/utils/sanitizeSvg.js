import sanitizeHtml from 'sanitize-html';

export function sanitizeSvg(svgContent) {
  // Very strict SVG whitelist
  return sanitizeHtml(svgContent, {
    allowedTags: [
      'svg','g','path','circle','ellipse','line','polygon','polyline','rect','text','defs','pattern','clipPath','mask','linearGradient','radialGradient','stop','title','desc','use','symbol','view'
    ],
    allowedAttributes: {
      '*': ['style','class','fill','stroke','stroke-width','opacity','transform','d','x','y','cx','cy','r','rx','ry','points','x1','y1','x2','y2','width','height','viewBox','preserveAspectRatio','id','href','xlink:href']
    },
    // Disallow script, on* handlers implicitly
    allowVulnerableTags: false,
    enforceHtmlBoundary: true,
    parser: { lowerCaseAttributeNames: false, lowerCaseTags: false }
  });
}
