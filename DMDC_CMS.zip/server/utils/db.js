// server/utils/db.js
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import dotenv from 'dotenv';
dotenv.config();

const DB_PATH = process.env.DB_PATH || process.env.DB_FILE || './data/app.db';

let dbPromise;
export async function getDb() {
  if (!dbPromise) {
    dbPromise = open({ filename: DB_PATH, driver: sqlite3.Database }).then(async db => {
      await db.exec('PRAGMA foreign_keys = ON');
      await db.exec('PRAGMA journal_mode = WAL');
      await db.exec('PRAGMA synchronous = NORMAL');
      await db.exec('PRAGMA busy_timeout = 3000');
      return db;
    });
  }
  return dbPromise;
}
