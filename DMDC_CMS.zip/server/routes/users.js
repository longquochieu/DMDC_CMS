import express from 'express';
import { requireAuth } from '../middlewares/auth.js';
import { getDb } from '../utils/db.js';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import sharp from 'sharp';
import bcrypt from 'bcryptjs';
import sqlite3 from 'sqlite3';

const router = express.Router();
const upload = multer({ dest: path.resolve('./uploads/tmp') });

router.get('/profile', requireAuth, async (req, res) => {
  const db = await getDb();
  const user = await db.get('SELECT id, username, email, role, avatar, last_login, last_activity FROM users WHERE id=?', req.user.id);
  res.render('users/profile', { pageTitle:'Tài khoản của tôi', me: user, error:null, success:null });
});

router.post('/profile', requireAuth, upload.single('avatar'), async (req, res) => {
  const db = await getDb();
  try{
    if (req.body.email) {
      await db.run('UPDATE users SET email=? WHERE id=?', req.body.email, req.user.id);
    }
    if (req.file) {
      const out = path.resolve('./uploads', `avatar_${req.user.id}.webp`);
      await sharp(req.file.path).resize(256,256,{fit:'cover'}).webp({quality:85}).toFile(out);
      await db.run('UPDATE users SET avatar=? WHERE id=?', (process.env.MEDIA_BASE_URL||'/uploads') + '/' + path.basename(out), req.user.id);
      fs.unlinkSync(req.file.path);
    }
    const user = await db.get('SELECT id, username, email, role, avatar, last_login, last_activity FROM users WHERE id=?', req.user.id);
    res.render('users/profile', { pageTitle:'Tài khoản của tôi', me:user, success:'Đã cập nhật hồ sơ.', error:null });
  }catch(e){
    const user = await db.get('SELECT id, username, email, role, avatar, last_login, last_activity FROM users WHERE id=?', req.user.id);
    res.render('users/profile', { pageTitle:'Tài khoản của tôi', me:user, success:null, error:e.message });
  }
});

router.post('/change-password', requireAuth, async (req, res) => {
  const { current_password, new_password } = req.body;
  const db = await getDb();
  const user = await db.get('SELECT * FROM users WHERE id=?', req.user.id);
  const ok = await bcrypt.compare(current_password, user.password_hash);
  if (!ok) {
    const me = await db.get('SELECT id, username, email, role, avatar, last_login, last_activity FROM users WHERE id=?', req.user.id);
    return res.render('users/profile', { pageTitle:'Tài khoản của tôi', me, error:'Mật khẩu hiện tại không đúng.', success:null });
  }
  const hash = await bcrypt.hash(new_password, 10);
  await db.run('UPDATE users SET password_hash=? WHERE id=?', hash, req.user.id);
  const me = await db.get('SELECT id, username, email, role, avatar, last_login, last_activity FROM users WHERE id=?', req.user.id);
  res.render('users/profile', { pageTitle:'Tài khoản của tôi', me, success:'Đã đổi mật khẩu.', error:null });
});

router.post('/logout-all', requireAuth, async (req, res) => {
  // Remove all sessions of this user from sessions.sqlite
  const sessPath = path.resolve('./data/sessions.sqlite');
  const dbSess = new sqlite3.Database(sessPath);
  dbSess.all('SELECT sid, sess FROM sessions', (err, rows) => {
    if (err) {
      return res.status(500).send('Không truy cập được session store.');
    }
    const toDelete = rows.filter(r => {
      try { const s = JSON.parse(r.sess); return s.userId === req.user.id; } catch(e){ return false; }
    }).map(r => r.sid);
    const placeholders = toDelete.map(_=>'?').join(',');
    if (toDelete.length) {
      dbSess.run(`DELETE FROM sessions WHERE sid IN (${placeholders})`, toDelete, (e2) => {
        dbSess.close();
        req.session.destroy(()=> res.redirect('/login'));
      });
    } else {
      dbSess.close();
      req.session.destroy(()=> res.redirect('/login'));
    }
  });
});

export default router;
