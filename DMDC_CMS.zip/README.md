# DMDC CMS — V1A (Node.js + Express + SQLite)

> Stack: Node.js 20+, Express, SQLite, EJS (AdminLTE 3 via CDN), csurf, helmet, express-session (SQLite store), bcryptjs, multer + sharp (WebP), sanitize-html (SVG sanitize), node-cron, slugify, uuid, pino.
> Spec: V1A đã khóa theo trao đổi: RBAC (Admin/Editor/Author/Contributor), Pages tree + `full_path` unique theo ngôn ngữ, Posts schedule (cron 5’), Media convert WebP & xoá bản gốc, SVG sanitize, Search FTS5, Trash 30 ngày + Empty, Settings (homepage, timezone/format, i18n URL mode), Users (login username/email, avatar, đổi mật khẩu, đăng xuất toàn bộ).

## 1) Chuẩn bị
- Cài Node 20+ (Windows 10 OK). Mở PowerShell trong thư mục dự án.
- Sao chép `.env.example` thành `.env` và chỉnh giá trị nếu cần.
- Cài gói:
```bash
npm install
```
- Khởi tạo DB + seed tài khoản Admin:
```bash
npm run db:init
npm run db:seed
```

## 2) Chạy dev
```bash
npm run dev
```
Mặc định chạy tại http://localhost:5000

## 3) Tài khoản Admin (seed)
- username: **admin**
- email: **admin@domain.com**
- password: **tạo ngẫu nhiên** và in ra console khi chạy `npm run db:seed` (đồng thời lưu vào `logs/admin_password.txt`).

## 4) Ghi chú quan trọng
- **Timezone**: Lưu UTC, hiển thị UTC+7 (Asia/Ho_Chi_Minh).
- **Media**: Mọi ảnh upload → **.webp** và **xoá bản gốc**. SVG được **sanitize**.
- **Trash**: Giữ 30 ngày → auto-purge (cron hàng ngày) + nút **Empty Trash** (Admin & Editor).
- **Publish quyền**: Bài Pending chỉ **Admin & Editor** được publish.
- **i18n URL**: Mặc định **path** (`/en/...`) — có thể đổi trong Settings (V2 áp dụng ở frontend).

## 5) Scripts
- `npm run db:init` — chạy tất cả migration trong thư mục `/migrations`.
- `npm run db:seed` — tạo admin mặc định, in password.
- `npm run dev` — chạy server với `nodemon` (hot reload).
- `npm start` — chạy server production.

## 6) Triển khai
- Prod: PM2 + Nginx; Redis sẽ dùng ở V2 (Bull Queue).
- Error logs tại `logs/error.log`.
